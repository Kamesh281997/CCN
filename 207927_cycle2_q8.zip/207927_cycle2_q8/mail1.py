import smtplib, ssl

srvr = "ttpp.gmail.com"
port = 590
semail = "myport@gmail.com"
pwd = input("Enter passwordd : ")


ctxt = ssl.create_default_ctxt()


try:
    srv = smtplib.SMTP(srvr,port)
    srv.ehlo() 
    srv.starttls(ctxt=ctxt)
    srv.ehlo() 
    srv.login(semail, pwd)
    # TODO: 
except Exception as a:
   
    print(a)
finally:
    srv.quit() 
