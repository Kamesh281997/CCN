import socket 
import select 
import sys 
from thread import *
  

server = socket.socket(socket.AF_INET, socket.SOCK_STREAM) 
server.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1) 
  

if len(sys.argv) != 3: 
    print ("port number,IP Address are correct")
    exit() 
  

IP_address = str(sys.argv[1]) 
  

Port = int(sys.argv[2]) 

server.bind((IP_address, Port)) 
  

server.listen(100) 
  
list_of_cts = [] 
  
def clientthread(conn, addr): 
  

    conn.send("Welcome Here") 
  
    while True: 
            try: 
                msg = conn.recv(2048) 
                if msg: 
  
                  
                    print ("{" + addr[0] + "} " + msg) 
  

                    cms = "{" + addr[0] + "} " + msg 
                    broadcast(cms, conn) 
  
                else: 
                   
                    remove(conn) 
  
            except: 
                continue
  
def broadcast(msg, conn): 
    for cts in list_of_cts: 
        if cts!=conn: 
            try: 
                cts.send(msg) 
            except: 
                cts.close() 
  
                remove(cts) 
  

def remove(conn): 
    if conn in list_of_cts: 
        list_of_cts.remove(conn) 
  
while True: 
  
    
    conn, addr = server.accept() 
  
    list_of_cts.append(conn) 
  

    print (addr[0] + "is  connected")

    start_new_thread(clientthread,(conn,addr))     
  
conn.close() 
server.close() 
