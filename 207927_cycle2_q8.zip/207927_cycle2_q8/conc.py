import os
import sys
import errno
import select
import socket
import optparse

BACKLOG = 5


def serve_forever(host, port):

    lstsock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)

    lstsock.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)

    lstsock.setblocking(0)

    lstsock.bind((host, port))
    lstsock.listen(BACKLOG)




    rlist, wlist, elist = [lstsock], [], []

    while True:
      
        readables, writables, exceptions = select.select(rlist, wlist, elist)

        for sock in readables:
            if sock is lstsock:
                try:
                    conn, client_address = lstsock.accept()
                except IOError as e:
                    code, msg = e.args
                    if code == errno.EINTR:
                        continue
                    else:
                        raise
            
                rlist.append(conn)
            else:

                bytes = sock.recv(1024)
                if not bytes: 
                    sock.close()
                    rlist.remove(sock)
                else:
                    print ('Got request to send %s bytes. '
                           'Sending them all...' % bytes)
                    

                    data = os.urandom(int(bytes))
                    sock.sendall(data)


def main():
    parser = optparse.OptionParser()
    parser.add_option(
        '-i', '--host', dest='host', default='0.0.0.0',
        help='Hostname or IP address. Default is 0.0.0.0'
        )

    parser.add_option(
        '-p', '--port', dest='port', type='int', default=2000,
        help='Port. Default is 2000')

    options, args = parser.parse_args()

    serve_forever(options.host, options.port)

if __name__ == '__main__':
    main()
